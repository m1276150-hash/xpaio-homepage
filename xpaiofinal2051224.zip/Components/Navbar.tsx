"use client";

import Link from "next/link";
import { useState } from "react";

export default function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 w-full z-50 bg-[#0D1B2A]/80 backdrop-blur-md border-b border-white/10">
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">

        {/* 로고 */}
        <Link href="/" className="text-2xl font-black text-neonBlue tracking-tight">
          XPAIO
        </Link>

        {/* 데스크탑 메뉴 */}
        <div className="hidden md:flex gap-10 text-white font-semibold">
          <Link href="/about" className="hover:text-neonBlue transition">About</Link>
          <Link href="/roadmap" className="hover:text-neonBlue transition">Roadmap</Link>
          <Link href="/games" className="hover:text-neonBlue transition">Games</Link>
          <Link href="/community" className="hover:text-neonBlue transition">Community</Link>
          <Link href="/faq" className="hover:text-neonBlue transition">FAQ</Link>
        </div>

        {/* 모바일 메뉴 버튼 */}
        <button
          className="md:hidden text-white text-3xl"
          onClick={() => setOpen(!open)}
        >
          ☰
        </button>
      </div>

      {/* 모바일 메뉴 */}
      {open && (
        <div className="md:hidden bg-[#0D1B2A]/95 backdrop-blur-md border-t border-white/10 px-6 py-4 space-y-4">
          <Link href="/about" className="block text-white text-lg">About</Link>
          <Link href="/roadmap" className="block text-white text-lg">Roadmap</Link>
          <Link href="/games" className="block text-white text-lg">Games</Link>
          <Link href="/community" className="block text-white text-lg">Community</Link>
          <Link href="/faq" className="block text-white text-lg">FAQ</Link>
        </div>
      )}
    </nav>
  );
}