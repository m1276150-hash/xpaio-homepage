'use client';

import React from 'react';
// 1. image_aa4c15 기준: 폴더명이 대문자 'Components'입니다.
import Header from '../../Components/Header'; 
// 2. image_f1fbe5 기준: about 폴더 안의 컴포넌트를 불러옵니다.
import { AboutInteractiveSection } from '../../Components/about/AboutInteractiveSection';

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-[#0D1B2A] text-white flex flex-col font-sans">
      
      {/* 상단 헤더 연결 */}
      <Header />

      <main className="flex-1 px-6 md:px-20 pt-32 max-w-7xl mx-auto w-full">
        <section className="text-center mb-16 md:mb-24">
          <h1 className="text-5xl md:text-8xl font-black mb-8 text-white tracking-tighter">
            Xpaio 로드맵
          </h1>
          <p className="text-xl md:text-3xl text-[#4ECDC4] font-bold mb-8 italic">
            "은하수가 이끄는 새로운 비전"
          </p>
        </section>

        <section className="text-center pb-32">
          {/* 인터랙티브 섹션 불러오기 */}
          <AboutInteractiveSection />
        </section>
      </main>
    </div>
  );
}