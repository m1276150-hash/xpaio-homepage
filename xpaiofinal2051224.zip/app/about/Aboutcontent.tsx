"use client";

import { motion } from "framer-motion";

export function AboutContent() {
  const roadmapSteps = [
    { title: "Phase 01", desc: "Xpaio 생태계의 기초 구축 및 커뮤니티 조성" },
    { title: "Phase 02", desc: "파이 네트워크 기반의 혁신적인 게임 런칭" },
    { title: "Phase 03", desc: "글로벌 유저 확장을 위한 공격적인 마케팅" },
    { title: "Phase 04", desc: "Xpaio만의 독자적인 거버넌스 및 경제 시스템 완성" }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-10 max-w-5xl mx-auto text-left">
      {roadmapSteps.map((step, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: index * 0.15 }}
          className="bg-white/5 p-10 rounded-[2.5rem] border border-white/10 shadow-xl hover:shadow-2xl transition-all backdrop-blur-sm"
        >
          <h3 className="text-3xl font-black text-[#4ECDC4] mb-4">
            {step.title}
          </h3>

          <p className="text-lg text-slate-300 font-medium leading-relaxed">
            {step.desc}
          </p>
        </motion.div>
      ))}
    </div>
  );
}