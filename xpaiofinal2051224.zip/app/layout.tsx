'use client';

import "./globals.css"; // styles/ 를 뺀 정확한 경로
import Navbar from "../Components/Navbar"; // 대문자 Components 확인

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ko">
      {/* 배경색과 글자색을 은하수님이 말씀하신 대로 직접 지정했습니다. */}
      <body className="bg-[#0D1B2A] text-white">
        <Navbar />
        <main className="pt-24">
          {children}
        </main>
      </body>
    </html>
  );
}