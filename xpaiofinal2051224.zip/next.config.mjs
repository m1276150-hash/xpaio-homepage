/** @type {import('next').NextConfig} */
const nextConfig = {
  // TurboPack 활성화
  turbopack: {},

  // React 개발 모드 강화
  reactStrictMode: true,

  // Next.js 이미지 최적화 비활성화 (Netlify 호환)
  images: {
    unoptimized: true,
  },

  // 브라우저에서 fs/path/os 오류 방지
  webpack: (config, { isServer }) => {
    if (!isServer) {
      config.resolve.fallback = {
        fs: false,
        path: false,
        os: false,
      };
    }
    return config;
  },
};

export default nextConfig;